import 'package:flutter/material.dart';
import 'package:mobileassignment3/database_helper.dart'; // Import your database helper

class MealPlanDetailsPage extends StatelessWidget {
  final Map<String, dynamic> mealPlan;
  final DatabaseHelper dbHelper = DatabaseHelper(); // Initialize your database helper

  MealPlanDetailsPage(this.mealPlan);

  Future<List<Map<String, dynamic>>> getSelectedFoods() async {
    try {
      int mealPlanId = mealPlan['id'];

      // Fetch selected foods and their quantities for the specified meal plan
      return await dbHelper.getSelectedFoodsForMealPlan(mealPlanId);
    } catch (e) {
      print('Error fetching selected foods: $e');
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    // Extract meal plan details
    int targetCalories = mealPlan['targetCalories'];
    String date = mealPlan['date'];

    return Scaffold(
      appBar: AppBar(
        title: Text('Meal Plan Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Date: $date'),
            Text('Target Calories: $targetCalories'),
            SizedBox(height: 20),
            Text(
              'Selected Foods:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: FutureBuilder<List<Map<String, dynamic>>>(
                future: getSelectedFoods(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else {
                    List<Map<String, dynamic>> selectedFoods = snapshot.data ?? [];
                    return ListView.builder(
                      itemCount: selectedFoods.length,
                      itemBuilder: (context, index) {
                        String foodName = selectedFoods[index]['name'];
                        int quantity = selectedFoods[index]['quantity'];

                        return ListTile(
                          title: Text(foodName),
                          subtitle: Text('Quantity: $quantity'),
                        );
                      },
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
