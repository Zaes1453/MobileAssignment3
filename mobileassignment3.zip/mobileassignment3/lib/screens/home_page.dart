import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:mobileassignment3/database_helper.dart';
import 'meal_plans_page.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final dbHelper = DatabaseHelper();
  int targetCalories = 2000;
  DateTime selectedDate = DateTime.now();
  List<Map<String, dynamic>> selectedFoods = [];

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2023),
      lastDate: DateTime(2024),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        // Reset selected foods when date changes
        selectedFoods.clear();
      });
    }
  }

  void _setTargetCalories() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        int newTargetCalories = targetCalories;
        return AlertDialog(
          title: Text('Set Target Calories'),
          content: TextField(
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'Enter Target Calories'),
            onChanged: (value) {
              newTargetCalories = int.tryParse(value) ?? targetCalories;
            },
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Set'),
              onPressed: () {
                setState(() {
                  targetCalories = newTargetCalories;
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  int getTotalCalories() {
    int totalCalories = 0;
    selectedFoods.forEach((food) {
      totalCalories += (food['calories'] as int) * (food['quantity'] as int);
    });
    return totalCalories;
  }
  Future<void> fetchFoods() async {
    try {
      List<Map<String, dynamic>> foods = await dbHelper.getFoods();
      print('Fetched foods: $foods');
    } catch (e) {
      print('Error fetching foods: $e');
    }
  }

  void _saveFoodPlan() async {
    // Prepare the meal plan data to be saved in the database

    var mealPlan = {
      'targetCalories': targetCalories,
      'date': DateFormat('yyyy-MM-dd').format(selectedDate),
    };

    await dbHelper.saveMealPlan(mealPlan);

    // Save selected foods associated with the saved meal plan
    List<Map<String, dynamic>> mealPlans = await dbHelper.getAllMealPlans();
    int mealPlanId = mealPlans.last['id']; // Get the ID of the last inserted meal plan

    await dbHelper.saveSelectedFoods(mealPlanId, selectedFoods);

    try {
      // Save the meal plan using DatabaseHelper
      await dbHelper.saveMealPlan(mealPlan);
      print('Meal plan saved successfully!');
    } catch (e) {
      print('Error saving meal plan: $e');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calories Calculator'),
        actions: [
          IconButton(
            icon: Icon(Icons.food_bank), // Icon for navigating to meal plans
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MealPlansPage()),
              );
            },
          ),
        ],
      ),
      body: FutureBuilder(
        future: dbHelper.getFoods(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            List<Map<String, dynamic>> foods = snapshot.data as List<Map<String, dynamic>>;
            return Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Target Calories: $targetCalories'),
                          ElevatedButton(
                            onPressed: _setTargetCalories,
                            child: Text('Set Target'),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Selected Date: ${DateFormat('yyyy-MM-dd').format(selectedDate)}'),
                          ElevatedButton(
                            onPressed: () => _selectDate(context),
                            child: Text('Select Date'),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: foods.length,
                        itemBuilder: (context, index) {
                          int foodCalories = foods[index]['calories'] as int;
                          int quantity = selectedFoods.isNotEmpty &&
                              selectedFoods.any((food) => food['id'] == foods[index]['id'])
                              ? selectedFoods.firstWhere((food) => food['id'] == foods[index]['id'])['quantity']
                              : 0;

                          return ListTile(
                            title: Text(foods[index]['name']),
                            subtitle: Text('$foodCalories calories'),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: Icon(Icons.remove),
                                  onPressed: () {
                                    setState(() {
                                      if (quantity > 0) {
                                        selectedFoods
                                            .firstWhere((food) => food['id'] == foods[index]['id'])['quantity']--;
                                      }
                                    });
                                  },
                                ),
                                Text(
                                  '$quantity',
                                  style: TextStyle(fontSize: 16.0),
                                ),
                                IconButton(
                                  icon: Icon(Icons.add),
                                  onPressed: () {
                                    setState(() {
                                      if (selectedFoods.isNotEmpty &&
                                          selectedFoods.any((food) => food['id'] == foods[index]['id'])) {
                                        selectedFoods
                                            .firstWhere((food) => food['id'] == foods[index]['id'])['quantity']++;
                                      } else {
                                        selectedFoods
                                            .add({...foods[index], 'quantity': 1});
                                      }
                                    });
                                  },
                                ),
                              ],
                            ),
                            onTap: () {
                              // Handle tapping on the ListTile if needed
                            },
                          );
                        },
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(8.0),
                      child: ElevatedButton(
                        onPressed: _saveFoodPlan,
                        child: Text('Save'),
                      ),
                    ),
                  ],
                ),
                Positioned(
                  bottom: 16.0,
                  right: 16.0,
                  child: Container(
                    padding: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Text(
                      'Total Calories: ${getTotalCalories()}',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            );
          }
        },
      ),
    );
  }
}
