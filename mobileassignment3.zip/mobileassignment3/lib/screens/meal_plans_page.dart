import 'package:flutter/material.dart';
import 'package:mobileassignment3/database_helper.dart';
import 'package:mobileassignment3/screens/meal_plan_details_page.dart';

class MealPlansPage extends StatefulWidget {
  @override
  _MealPlansPageState createState() => _MealPlansPageState();
}

class _MealPlansPageState extends State<MealPlansPage> {
  final DatabaseHelper dbHelper = DatabaseHelper();
  List<Map<String, dynamic>> mealPlans = [];
  DateTime? selectedDate;

  @override
  void initState() {
    super.initState();
    fetchMealPlans();
  }

  Future<void> fetchMealPlans() async {
    try {
      List<Map<String, dynamic>> plans = await dbHelper.getAllMealPlans();
      setState(() {
        mealPlans = plans;
      });
    } catch (e) {
      print('Error fetching meal plans: $e');
    }
  }

  void filterMealPlansByDate(DateTime selectedDate) {
    setState(() {
      this.selectedDate = selectedDate;
      mealPlans = mealPlans.where((plan) {
        DateTime planDate = DateTime.parse(plan['date']);
        return planDate.year == selectedDate.year &&
            planDate.month == selectedDate.month &&
            planDate.day == selectedDate.day;
      }).toList();
    });
  }

  Future<void> deleteMealPlan(int mealPlanId) async {
    try {
      await dbHelper.deleteMealPlan(mealPlanId);
      setState(() {
        mealPlans.removeWhere((plan) => plan['id'] == mealPlanId);
      });
    } catch (e) {
      print('Error deleting meal plan: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Meal Plans'),
      ),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: () async {
              DateTime? pickedDate = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(2022),
                lastDate: DateTime(2025),
              );
              if (pickedDate != null) {
                filterMealPlansByDate(pickedDate);
              }
            },
            child: Text('Select Date'),
          ),
          Expanded(
            child: mealPlans.isEmpty
                ? Center(child: Text('No meal plans available'))
                : ListView.builder(
              itemCount: mealPlans.length,
              itemBuilder: (context, index) {
                int mealPlanId = mealPlans[index]['id'];
                String date = mealPlans[index]['date'];
                int targetCalories = mealPlans[index]['targetCalories'];

                return ListTile(
                  title: Text('Date: $date'),
                  subtitle: Text('Target Calories: $targetCalories'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            MealPlanDetailsPage(mealPlans[index]),
                      ),
                    );
                  },
                  trailing: IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () {
                      deleteMealPlan(mealPlanId);
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
