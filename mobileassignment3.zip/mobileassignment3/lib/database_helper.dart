import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;

  static Database? _db;

  DatabaseHelper._internal();

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await initDb();
    return _db!;
  }

  Future<Database> initDb() async {
    var directory = await getApplicationDocumentsDirectory();
    String path = join(directory.path, 'calories.db');
    var database = await openDatabase(path, version: 1, onCreate: _onCreate, onUpgrade: _onUpgrade);
    await _insertInitialFoods(database);
    return database;
  }

  void _onUpgrade(Database db, int oldVersion, int newVersion) {
    if (oldVersion < 2) {
      _onCreate(db, newVersion);
    }
  }

  void _onCreate(Database db, int version) async {
    try {
      await db.execute('''
      CREATE TABLE IF NOT EXISTS foods(
        id INTEGER PRIMARY KEY,
        name TEXT,
        calories INTEGER
      )''');

      await db.execute('''
      CREATE TABLE IF NOT EXISTS meal_plans(
        id INTEGER PRIMARY KEY,
        targetCalories INTEGER,
        date TEXT
      )''');

      await db.execute('''
      CREATE TABLE IF NOT EXISTS selected_foods(
        id INTEGER PRIMARY KEY,
        mealPlanId INTEGER,
        name TEXT,
        quantity INTEGER
      )''');

      print('Tables created successfully');
    } catch (e) {
      print('Error creating tables: $e');
    }
  }


  Future<void> _insertInitialFoods(Database db) async {
    // Add the new foods to the 'foods' table with their calories
    await db.insert('foods', {'name': 'Banana', 'calories': 105});
    await db.insert('foods', {'name': 'Orange', 'calories': 62});
    await db.insert('foods', {'name': 'Strawberry', 'calories': 50});
    await db.insert('foods', {'name': 'Blueberry', 'calories': 57});
    await db.insert('foods', {'name': 'Pineapple', 'calories': 83});
    await db.insert('foods', {'name': 'Grapes', 'calories': 69});
    await db.insert('foods', {'name': 'Watermelon', 'calories': 30});
    await db.insert('foods', {'name': 'Avocado', 'calories': 160});
    await db.insert('foods', {'name': 'Cucumber', 'calories': 45});
    await db.insert('foods', {'name': 'Carrot', 'calories': 41});
    await db.insert('foods', {'name': 'Broccoli', 'calories': 55});
    await db.insert('foods', {'name': 'Tomato', 'calories': 22});
    await db.insert('foods', {'name': 'Bell Pepper', 'calories': 31});
    await db.insert('foods', {'name': 'Lettuce', 'calories': 5});
    await db.insert('foods', {'name': 'Spinach', 'calories': 23});
    await db.insert('foods', {'name': 'Onion', 'calories': 40});
    await db.insert('foods', {'name': 'Garlic', 'calories': 149});
    await db.insert('foods', {'name': 'Potato', 'calories': 163});
    await db.insert('foods', {'name': 'Rice', 'calories': 130});
    await db.insert('foods', {'name': 'Pasta', 'calories': 221});
  }


  Future<void> saveSelectedFoods(int mealPlanId, List<Map<String, dynamic>> selectedFoods) async {
  var dbClient = await db;

  for (var food in selectedFoods) {
  food['mealPlanId'] = mealPlanId;
  await dbClient.insert('selected_foods', food);
  }
  }

  Future<List<Map<String, dynamic>>> getSelectedFoodsForMealPlan(int mealPlanId) async {
  var dbClient = await db;
  return dbClient.query('selected_foods', where: 'mealPlanId = ?', whereArgs: [mealPlanId]);
  }



  Future<List<Map<String, dynamic>>> getFoods() async {
    var dbClient = await db;
    return dbClient.query('foods');
  }
  Future<void> saveFood(Map<String, dynamic> food) async {
    var dbClient = await db;
    await dbClient.insert('foods', food);
  }


  Future<void> saveMealPlan(Map<String, dynamic> mealPlan) async {
    var dbClient = await db;
    await dbClient.insert('meal_plans', mealPlan);
  }

  Future<List<Map<String, dynamic>>> getAllMealPlans() async {
    var dbClient = await db;
    return dbClient.query('meal_plans');
  }

  Future<void> deleteMealPlan(int mealPlanId) async {
    try {
      var dbClient = await db;
      await dbClient.delete('meal_plans', where: 'id = ?', whereArgs: [mealPlanId]);
      print('Meal plan deleted successfully');
    } catch (e) {
      print('Error deleting meal plan: $e');
      rethrow;
    }
  }


  Future<void> printDatabaseSchema() async {
    var dbClient = await db;
    List<Map<String, dynamic>> tables = await dbClient.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table';",
    );

    for (var table in tables) {
      List<Map<String, dynamic>> columns = await dbClient.rawQuery(
        "PRAGMA table_info(${table['name']});",
      );

      print('Table: ${table['name']}');
      for (var column in columns) {
        print('Column: ${column['name']} - Type: ${column['type']}');
      }
      print('\n');
    }
  }
}
