import 'package:flutter/material.dart';
import 'package:mobileassignment3/database_helper.dart';
import 'package:mobileassignment3/screens/home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  var dbHelper = DatabaseHelper();
  await dbHelper.initDb();
  await dbHelper.printDatabaseSchema();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calories Calculator',
      home: HomePage(),
    );
  }
}
